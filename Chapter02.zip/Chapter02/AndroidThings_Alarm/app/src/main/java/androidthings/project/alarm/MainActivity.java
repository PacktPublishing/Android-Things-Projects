/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidthings.project.alarm;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.things.pio.Gpio;
import com.google.android.things.pio.GpioCallback;
import com.google.android.things.pio.PeripheralManagerService;

import java.io.IOException;

/**
 * Skeleton of the main Android Things activity. Implement your device's logic
 * in this class.
 *
 * Android Things peripheral APIs are accessible through the class
 * PeripheralManagerService. For example, the snippet below will open a GPIO pin and
 * set it to HIGH:
 *
 * <pre>{@code
 * PeripheralManagerService service = new PeripheralManagerService();
 * mLedGpio = service.openGpio("BCM6");
 * mLedGpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * mLedGpio.setValue(true);
 * }</pre>
 *
 * For more complex peripherals, look for an existing user-space driver, or implement one if none
 * is available.
 *
 */
public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();


    private Gpio gpioPin;
    private SensorCallBack sensorCallBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        PeripheralManagerService service = new PeripheralManagerService();
        try {
            gpioPin = service.openGpio(BoardPins.getPirPin());
            gpioPin.setDirection(Gpio.DIRECTION_IN);
            gpioPin.setActiveType(Gpio.ACTIVE_HIGH);

            boolean status = gpioPin.getValue();
            Log.d(TAG, "Status ["+status+"]");

            sensorCallBack = new SensorCallBack();
            gpioPin.setEdgeTriggerType(Gpio.EDGE_RISING);
            gpioPin.registerGpioCallback(sensorCallBack);


/*
            (new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true) {
                            boolean status = gpioPin.getValue();
                            Log.d(TAG, "Sensor status [" + status + "]");
                            if (status) {
                                Log.i(TAG, "Motion detected..");
                            }
                            Thread.sleep(5000);
                        }
                    }
                    catch(Exception e) {
                        e.printStackTrace();
                    }
                }
            })).start();
 */

        }
        catch(IOException ioe) {
            // Ignore it
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
        if (gpioPin != null) {
            gpioPin.unregisterGpioCallback(sensorCallBack);
            try {
                gpioPin.close();
                gpioPin = null;
            }
            catch(Exception e) {}
        }
    }

    private class SensorCallBack extends GpioCallback {
        @Override
        public boolean onGpioEdge(Gpio gpio) {
            try {
                boolean callBackState = gpio.getValue();
                Log.d(TAG, "Call back state ["+callBackState+"]");
                NotificationManager.getInstance().sendNotificaton("Alarm!", "AAAAL1SEEv0:APA91bHuKKL8dvC95tFxLjVTX9N4dMPfL-UruhFUw-_XR-7uqwAOy3F4RLj6gJQWk7IAaVTYDMAxmIq3DzjLrG-cmylJR1gk6U-umbG5V164oZqIbHw5P6MPhsBkXNOA1k33eNBBeU5k");
            }
            catch(IOException ioe) {
                ioe.printStackTrace();
            }

            return true;
        }

        @Override
        public void onGpioError(Gpio gpio, int error) {
            super.onGpioError(gpio, error);
        }
    }
}
