package androidthings.project.weather;

import android.util.Log;

import com.temboo.Library.Nexmo.Voice.TextToSpeech;
import com.temboo.core.TembooException;
import com.temboo.core.TembooSession;

/**
 * Created by francesco on 04/03/2017.
 */

public class TembooClient {

    private static final String TAG = "Temboo";
    private static TembooClient me;
    private TembooSession session;
    private static final String ID = "survivingwithandroid";
    private static final String KEY = "97a2875fbe6547259fa4ecca14696737";

    private TembooClient() {
        try {
            Log.d(TAG, "Temboo session init...");
            session = new TembooSession(ID, "myFirstApp", KEY);
            Log.d(TAG, "Temboo session ["+session+"]");
        }
        catch (TembooException te) {
            te.printStackTrace();
        }
    }

    public static TembooClient getInstance() {
        if (me == null)
            me = new TembooClient();

        return me;
    }

    public void callTemboo() {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Call Temboo...");
                TextToSpeech textToSpeechChoreo = new TextToSpeech(session);

// Get an InputSet object for the choreo
                TextToSpeech.TextToSpeechInputSet textToSpeechInputs = textToSpeechChoreo.newInputSet();

// Set inputs
                textToSpeechInputs.set_APIKey("934bacee");
                textToSpeechInputs.set_Text("Hello, the temperature is too high");
                textToSpeechInputs.set_To("393471127403");
                textToSpeechInputs.set_APISecret("1a978217ef3a3c0c");

// Execute Choreo
                try {
                    TextToSpeech.TextToSpeechResultSet textToSpeechResults = textToSpeechChoreo.execute(textToSpeechInputs);
                    Log.d(TAG, "TTS Result ["+textToSpeechResults.get_Response()+"]");
                }
                catch (TembooException te) {
                    te.printStackTrace();
                }

            }
        };

        Thread t = new Thread(r);
        t.start();
    }


}
