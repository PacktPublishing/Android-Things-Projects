package androidthings.project.weather;

import android.os.Build;

import com.google.android.things.pio.PeripheralManagerService;

import java.util.List;

/**
 * Created by francesco on 10/02/2017.
 */

public class BoardPins {
    private static final String EDISON_ARDUINO = "edison_arduino";
    private static final String RASPBERRY = "rpi3";

    public static String getRedPin() {
        switch (getBoardName()) {
            case RASPBERRY:
                return "BCM6";
            case EDISON_ARDUINO:
                return "IO4";
            default:
                throw new IllegalArgumentException("Unsupported device");
        }
    }

    public static String getBluePin() {
        switch (getBoardName()) {
            case RASPBERRY:
                return "BCM26";
            case EDISON_ARDUINO:
                return "IO4";
            default:
                throw new IllegalArgumentException("Unsupported device");
        }
    }

    public static String getGreenPin() {
        switch (getBoardName()) {
            case RASPBERRY:
                return "BCM19";
            case EDISON_ARDUINO:
                return "IO4";
            default:
                throw new IllegalArgumentException("Unsupported device");
        }
    }

    public static String getSDAPin() {
        switch (getBoardName()) {
            case RASPBERRY:
                return "I2C1";
            case EDISON_ARDUINO:
                return "IO4";
            default:
                throw new IllegalArgumentException("Unsupported device");
        }
    }


    public static String getRedLedPin() {
        switch (getBoardName()) {
            case RASPBERRY:
                return "BCM5";
            case EDISON_ARDUINO:
                return "IO4";
            default:
                throw new IllegalArgumentException("Unsupported device");
        }
    }

    private static String getBoardName() {
        String name = Build.BOARD;
        if (name.equals("edison")) {
            PeripheralManagerService service = new PeripheralManagerService();
            List<String> pinList = service.getGpioList();
            if (pinList.size() > 0) {
                String pinName = pinList.get(0);
                if (pinName.startsWith("IO"))
                    return EDISON_ARDUINO;
            }
        }

        return name;
    }
}
