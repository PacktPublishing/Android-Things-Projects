/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidthings.project.weather;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;

import com.google.android.things.contrib.driver.bmx280.Bmx280;
import com.google.android.things.contrib.driver.bmx280.Bmx280SensorDriver;
import com.google.android.things.pio.Gpio;
import com.google.android.things.pio.PeripheralManagerService;

import java.io.IOException;

/**
 * Skeleton of the main Android Things activity. Implement your device's logic
 * in this class.
 *
 * Android Things peripheral APIs are accessible through the class
 * PeripheralManagerService. For example, the snippet below will open a GPIO pin and
 * set it to HIGH:
 *
 * <pre>{@code
 * PeripheralManagerService service = new PeripheralManagerService();
 * mLedGpio = service.openGpio("BCM6");
 * mLedGpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * mLedGpio.setValue(true);
 * }</pre>
 *
 * For more complex peripherals, look for an existing user-space driver, or implement one if none
 * is available.
 *
 */
public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private SensorManager sensorManager;
    private Bmx280SensorDriver mySensorDriver;
    private BMX280Callback callback;

    private PeripheralManagerService pManager;

    private Gpio redPin;
    private Gpio bluePin;
    private Gpio greenPin;

    private Gpio redLedPin;

    private static final float LEVEL_1 = 1022.69f;
    private static final float LEVEL_2 = 1009.14f;

    private int currentWeather = -100;
    private TemperatureCallback tempCallback;
    private PressureCallback pressCallback;
    boolean currentState = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate...");

        // testI2C();
         testSensorManager();
        //testHumidity();
    }

    private void testI2C() {
        try {
            Bmx280 sensor = new Bmx280("I2C1");
            sensor.setTemperatureOversampling(Bmx280.OVERSAMPLING_1X);
            sensor.setPressureOversampling(Bmx280.OVERSAMPLING_1X);
            float val = sensor.readTemperature();
            Log.d(TAG, "Temp ["+val+"]");
            float press = sensor.readPressure();
            Log.d(TAG, "Press ["+press+"]");
        }

        catch(Throwable t) {
            t.printStackTrace();
        }
    }

    private void testSensorManager() {
        pManager = new PeripheralManagerService();
        initRGBPins();

        try {
            redPin.setValue(false);
            greenPin.setValue(false);
            bluePin.setValue(true);

            redLedPin.setValue(false);
        }
        catch(Throwable t) {
            t.printStackTrace();
        }
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        callback = new BMX280Callback();
        sensorManager.registerDynamicSensorCallback(callback);
        try {
            mySensorDriver = new Bmx280SensorDriver(BoardPins.getSDAPin());

            mySensorDriver.registerTemperatureSensor();
            mySensorDriver.registerPressureSensor();
        }
        catch(Throwable t) {
            t.printStackTrace();
        }
    }

    private void testHumidity() {
        try {
            androidthings.project.weather.Bmx280 sensor = new androidthings.project.weather.Bmx280(BoardPins.getSDAPin());
            sensor.setTemperatureOversampling(androidthings.project.weather.Bmx280.OVERSAMPLING_1X);
            sensor.setPressureOversampling(androidthings.project.weather.Bmx280.OVERSAMPLING_1X);
            long adH = sensor.readHumidity();
            double hum = sensor.readCompansatedHumidity();
            Log.d("App", "ADH ["+adH+"]");
            Log.d("App", "Hum ["+hum+"]");
        }
        catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
        sensorManager.unregisterListener(tempCallback);
        sensorManager.unregisterListener(pressCallback);
        mySensorDriver.unregisterTemperatureSensor();
        mySensorDriver.registerPressureSensor();

        try {
          mySensorDriver.close();
        }
        catch (IOException ioe) {}
    }

    private void initRGBPins() {
        try {
            redPin = pManager.openGpio(BoardPins.getRedPin());
            redPin.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
            redPin.setActiveType(Gpio.ACTIVE_LOW);

            greenPin = pManager.openGpio(BoardPins.getGreenPin());
            greenPin.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
            greenPin.setActiveType(Gpio.ACTIVE_LOW);

            bluePin = pManager.openGpio(BoardPins.getBluePin());
            bluePin.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
            bluePin.setActiveType(Gpio.ACTIVE_LOW);

            redLedPin = pManager.openGpio(BoardPins.getRedLedPin());
            redLedPin.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
            redLedPin.setActiveType(Gpio.ACTIVE_HIGH);

        }
        catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }


    private class BMX280Callback extends SensorManager.DynamicSensorCallback {
        @Override
        public void onDynamicSensorConnected(Sensor sensor) {
            int sensorType = sensor.getType();
            Log.d(TAG, "On Sensor connected...");
            if (sensorType == Sensor.TYPE_AMBIENT_TEMPERATURE) {
               Log.d(TAG, "Temp sensor..");
                tempCallback= new TemperatureCallback();
                sensorManager.registerListener(
                         tempCallback,
                         sensor,
                         SensorManager.SENSOR_DELAY_NORMAL);
            }
            else  if (sensorType == Sensor.TYPE_PRESSURE) {
                Log.d(TAG, "Pressure sensor..");
                pressCallback = new PressureCallback();
                sensorManager.registerListener(
                        pressCallback,
                        sensor,
                        SensorManager.SENSOR_DELAY_NORMAL);
            }
        }

        @Override
        public void onDynamicSensorDisconnected(Sensor sensor) {
            super.onDynamicSensorDisconnected(sensor);
        }
    }

    private class TemperatureCallback implements SensorEventListener {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float val = sensorEvent.values[0];
            boolean turnOn = false;
            if (val<= 0)
                turnOn = true;
            else
                turnOn = false;

            if (currentState != turnOn) {
                Log.d(TAG, "Change RED led color. New state ["+turnOn+"]");
                try {
                    redLedPin.setValue(turnOn);
                    currentState = turnOn;
                }
                catch(IOException ioe) {
                    ioe.printStackTrace();
                }
            }
            Log.d(TAG, "Temp ["+val+"]");
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            Log.d(TAG, "T. Accuracy ["+i+"]");
        }
    }

    private class PressureCallback implements SensorEventListener {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float val = sensorEvent.values[0];

            int newWeather = -200;
            if (val >= LEVEL_1)
                newWeather = 1;
            else if (val >= LEVEL_2 && val <= LEVEL_1)
                newWeather = 0;
            else
                newWeather = -1;

            if (newWeather != currentWeather) {
                currentWeather = newWeather;
                // Set the RGB color
                switch (newWeather) {
                    case 1:
                        setRGBPins(true, true, false);
                        break;
                    case 0:
                        setRGBPins(false, true, false);
                        break;
                    case -1:
                        setRGBPins(false, false, true);
                        break;
                }
            }
            Log.d(TAG, "Current weather ["+currentWeather+"] - Pres ["+val+"]");
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            Log.d(TAG, "P. Accuracy ["+i+"]");
        }
    }


    private void setRGBPins(boolean red, boolean green, boolean blue) {
        try {
            Log.d(TAG, "Change RGB led color. Red ["+red+"] - Green ["+green+"] - Blue ["+blue+"]");
            redPin.setValue(red);
            greenPin.setValue(green);
            bluePin.setValue(blue);
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
