package androidthings.project.spycam;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.media.ImageReader;
import android.media.tv.TvInputService;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.IntDef;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.Collections;

/**
 * Created by francesco on 08/04/2017.
 */

public class AndroidCamera {

    private Context ctx;
    private static final String TAG = "AndroidCamera";
    private String camId;
    private CameraManager cManager;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CameraListener listener;
    private ImageReader iReader;


    private HandlerThread imgHandler = new HandlerThread("ImageThread");

    public AndroidCamera(Context ctx, CameraListener listener) {
        this.ctx = ctx;
        this.listener = listener;
    }

    public void initCamera() {

        cManager =  (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        Log.d(TAG, "Camera Manager ["+cManager+"]");

        // Retrieve the list of cams
        try {
            String[] idCams = cManager.getCameraIdList();
            Log.d(TAG, "Camera Ids ["+idCams+"]");
            camId = idCams[0];

        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        // Initialize the ImageReader
        imgHandler.start();
        iReader = ImageReader.newInstance(320, 240, ImageFormat.JPEG, 1);
        iReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                listener.onImageReady(reader);
            }
        }, new Handler(imgHandler.getLooper()));
    }


    public void openCamera() {
        try {
            CameraCharacteristics characteristics = cManager.getCameraCharacteristics(camId);
            cManager.openCamera(camId, stateCallback, null);

        } catch (CameraAccessException e) {
            e.printStackTrace();
        } catch (SecurityException se)  {
            se.printStackTrace();
        }
    }

    public void takePicture() {
        try {
            camera.createCaptureSession(Collections.singletonList(iReader.getSurface()),
                    sessionCallback, null);
        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }


    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            Log.d(TAG, "Camera opened");
            AndroidCamera.this.camera = camera;
            listener.onCameraAvailable();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice camera) {
            Log.d(TAG, "Camera disconnected");
        }

        @Override
        public void onError(@NonNull CameraDevice camera, int error) {
            Log.d(TAG, "Camera Error" + error);
        }
    };


    private CameraCaptureSession.StateCallback sessionCallback = new CameraCaptureSession.StateCallback() {
        @Override
        public void onConfigured(@NonNull CameraCaptureSession session) {
            Log.d(TAG, "Camera configured");
            AndroidCamera.this.session = session;
            startCaptureImage();
        }

        @Override
        public void onConfigureFailed(@NonNull CameraCaptureSession session) {
            Log.e(TAG, "Configuration failed");

        }
    };


    private void startCaptureImage() {
        try {
            CaptureRequest.Builder captureBuilder =
                    camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(iReader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            Log.d(TAG, "Session initialized.");
            session.capture(captureBuilder.build(), captureCallback, null);
        }
        catch(CameraAccessException cae) {
            cae.printStackTrace();
        }

    }

    private CameraCaptureSession.CaptureCallback captureCallback = new CameraCaptureSession.CaptureCallback() {
        @Override
        public void onCaptureCompleted(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull TotalCaptureResult result) {
            Log.d(TAG, "Capture completed");
            session.close();
        }
    };

    public static interface CameraListener {
        public void onCameraAvailable();
        public void onImageReady(ImageReader reader);
    }

}
