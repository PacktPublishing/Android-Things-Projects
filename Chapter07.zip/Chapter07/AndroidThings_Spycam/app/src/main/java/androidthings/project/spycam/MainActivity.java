/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidthings.project.spycam;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.things.contrib.driver.pwmservo.Servo;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Skeleton of the main Android Things activity. Implement your device's logic
 * in this class.
 *
 * Android Things peripheral APIs are accessible through the class
 * PeripheralManagerService. For example, the snippet below will open a GPIO pin and
 * set it to HIGH:
 *
 * <pre>{@code
 * PeripheralManagerService service = new PeripheralManagerService();
 * mLedGpio = service.openGpio("BCM6");
 * mLedGpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * mLedGpio.setValue(true);
 * }</pre>
 *
 * For more complex peripherals, look for an existing user-space driver, or implement one if none
 * is available.
 *
 */
public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private Servo mServo;
    private Handler mHandler;

    private Button btnPicture;
    private ImageView imgView;


    private int angle = 0;
    private final int STEP = 15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
        Log.d(TAG, "onCreate");
        initServo();
        final AndroidCamera aCamera = new AndroidCamera(this, listener);
        aCamera.initCamera();
        aCamera.openCamera();

        imgView = (ImageView) findViewById(R.id.img);

        btnPicture = (Button) findViewById(R.id.btnPicture);
        btnPicture.setEnabled(false);
        btnPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Start caputring the image");
                aCamera.takePicture();
            }
        });

        Button btnLeft = (Button) findViewById(R.id.btnLeft);
        Button btnRight = (Button) findViewById(R.id.btnRight);

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angle += STEP;
                setServoAngle(angle);
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angle -= STEP;
                setServoAngle(angle);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    private void initServo() {
        try {
            mServo = new Servo("PWM0");
            mServo.setAngleRange(0f, 180f);
            mServo.setEnabled(true);

        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }

    private AndroidCamera.CameraListener listener = new AndroidCamera.CameraListener() {
        @Override
        public void onCameraAvailable() {
            Log.d(TAG, "Camera Ready");
            btnPicture.setEnabled(true);
        }

        @Override
        public void onImageReady(ImageReader reader) {
          Log.d(TAG, "Image ready");
            Image img1 = reader.acquireLatestImage();
            ByteBuffer bBuffer = img1.getPlanes()[0].getBuffer();
            final byte[] buffer = new byte[bBuffer.remaining()];
            bBuffer.get(buffer);
            img1.close();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    imgView.setImageBitmap( BitmapFactory.decodeByteArray(buffer, 0, buffer.length) );

                }
            });
        }
    };

    private void setServoAngle(int angle) {
        if (angle > mServo.getMaximumAngle())
            angle = (int) mServo.getMinimumAngle();

        if (angle < mServo.getMinimumAngle())
            angle = (int) mServo.getMinimumAngle();

        try {
            mServo.setAngle(angle);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

