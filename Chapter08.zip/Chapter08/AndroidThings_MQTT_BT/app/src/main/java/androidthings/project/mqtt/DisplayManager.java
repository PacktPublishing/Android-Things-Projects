package androidthings.project.mqtt;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.util.Log;

import com.google.android.things.contrib.driver.ssd1306.BitmapHelper;
import com.google.android.things.contrib.driver.ssd1306.Ssd1306;

import java.io.IOException;


/**
 * Created by francesco on 02/04/2017.
 */

public class DisplayManager {

    private Ssd1306 display;
    private Handler h = new Handler();

    public DisplayManager() {
        try {
            display = new Ssd1306("your_pin");
            display.clearPixels();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void displayMessage(final String msg, final int size, final int color) {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                display.clearPixels();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setTextSize(size);
                p.setColor(color);
                p.setTextAlign(Paint.Align.LEFT);
                int width = display.getLcdWidth();
                int height = display.getLcdHeight();

                Log.d("DISPLAY", "Height ["+height+"] - Width ["+width+"]");
                Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b);

                c.drawText(msg, 0, 0.5f * height, p);
                BitmapHelper.setBmpData(display, 0, 0, b, true);
                try {
                    display.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };

        h.post(r);

    }
}
