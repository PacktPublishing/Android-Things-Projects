package androidthings.project.ledstrip;

import android.os.Build;

import com.google.android.things.pio.PeripheralManagerService;

import java.util.List;

/**
 * Created by francesco on 10/02/2017.
 */

public class Boards {
    private static final String EDISON_ARDUINO = "edison_arduino";
    private static final String RASPBERRY = "rpi3";

    public static boolean enableWebserver() {
        switch (getBoardName()) {
            case RASPBERRY:
                return false;
            case EDISON_ARDUINO:
                return true;
            default:
                throw new IllegalArgumentException("Unsupported device");
        }
    }


    private static String getBoardName() {
        String name = Build.BOARD;
        if (name.equals("edison")) {
            PeripheralManagerService service = new PeripheralManagerService();
            List<String> pinList = service.getGpioList();
            if (pinList.size() > 0) {
                String pinName = pinList.get(0);
                if (pinName.startsWith("IO"))
                    return EDISON_ARDUINO;
            }
        }

        return name;
    }
}
