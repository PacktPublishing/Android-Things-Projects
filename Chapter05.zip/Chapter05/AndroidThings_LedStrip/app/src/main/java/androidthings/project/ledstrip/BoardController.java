package androidthings.project.ledstrip;

import android.util.Log;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by francesco on 18/03/2017.
 */

public class BoardController {

    private static final String TAG = "Client";

    private static BoardController me;
    private OkHttpClient client;

    private static final String baseUrl = "http://192.168.1.3/";

    private BoardController()  {
        client = new OkHttpClient();
    }

    public static BoardController getInstance() {
        if (me == null)
            me = new BoardController();

        return me;
    }

    public void sendData(int r, int g, int b, int wait, int dir, int func) {
        String hexColor = getHex(r) + getHex(g) + getHex(b);

        String params = Integer.toString(dir) + hexColor + ( (wait < 10) ? "0" + Integer.toString(wait) : Integer.toString(wait)) + "9";
        String url = baseUrl;

        switch (func) {
            case 0:
               url += "fill";
                break;
            case 1:
                url += "clear";
                break;
            case 2:
                url += "rainbow";

        }

        Log.d(TAG, "URL ["+url+"] - Params ["+params+"]");


        Request request = new Request.Builder()
                .url(url + "?params=" + params)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "Response ["+response.body().string()+"]");
            }
        });

    }

    private String getHex(int val) {
        String hex = Integer.toHexString(val);
        if (hex.length() < 2)
            hex = "0" + hex;

        return hex;
    }


}
