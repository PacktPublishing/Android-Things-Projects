/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidthings.project.mqtt;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;


import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity implements MQTTClient.MQTTListener {
    private static final String TAG = MainActivity.class.getSimpleName();

    private DisplayManager dm;
    private MQTTClient mqttClient;

    private TextView chView;
    private TextView tempView;
    private TextView pressView;
    private TextView humView;
    private TextView luxView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        Log.d(TAG, "onCreate");
        initView();
        initMQTT();
        initDisplay();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }


    @Override
    public void onConnected() {
        mqttClient.subscribe("channel1");
    }

    @Override
    public void onConnectionFailure(Throwable t) {

    }

    @Override
    public void onMessage(String topic, MqttMessage message) {
        dm.displayMessage(topic, 30, Color.WHITE);

        // Parse the payload
        Log.d(TAG, "Parsing message...");
        String payload = new String(message.getPayload());
        Log.d(TAG, "Payload ["+payload+"]");
        try {
            JSONObject obj = new JSONObject(payload);
            String temp = obj.getString("temp");
            String press = obj.getString("press");
            String hum = obj.getString("hum");
            String lux = obj.optString("light");
            updateView(topic, temp, press, hum, lux);
        }
        catch(JSONException jse) {
            jse.printStackTrace();
        }
    }

    @Override
    public void onError(MqttException mqe) {

    }

    private void initMQTT() {
        mqttClient = MQTTClient.getInstance(this);
        mqttClient.setListener(this);
        mqttClient.connectToMQTT();

    }

    private void initDisplay() {
        dm = new DisplayManager();
        dm.displayMessage("Welcome..", 30, Color.WHITE);
    }

    private void initView() {
        chView = (TextView) findViewById(R.id.topic);
        tempView = (TextView) findViewById(R.id.temp);
        pressView = (TextView) findViewById(R.id.press);
        humView = (TextView) findViewById(R.id.hum);
        luxView = (TextView) findViewById(R.id.lux);

    }

    private void updateView(String topic, String temp, String press, String hum, String lux) {
        chView.setText(topic);
        tempView.setText(temp);
        pressView.setText(press);
        humView.setText(hum);
        luxView.setText(lux);
    }
}
